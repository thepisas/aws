
--------------------------------Start ETL_ERR_AUDIT--------------------------------------
CREATE TABLE ETL_AUDIT.ETL_ERR_AUDIT
(
   ETL_ERR_ID                    NUMBER(12)           GENERATED ALWAYS AS IDENTITY NOT NULL,
   TABLE_NM                      VARCHAR2(60 Byte),
   COLUMN_NM                     VARCHAR2(60 Byte),
   NATURAL_KEY_COLUMN_NM_TXT     VARCHAR2(255 Byte),
   NATURAL_KEY_COLUMN_VALUE_TXT  VARCHAR2(255 Byte),
   ERR_CD                        VARCHAR2(20 Byte),
   ERR_TXT                       VARCHAR2(255 Byte),
   COLUMN_ERR_VALUE_TXT          VARCHAR2(255 Byte),
   MAPPING_NM                    VARCHAR2(60 Byte),
   RECORD_INSERT_TMSTMP          TIMESTAMP(6)         DEFAULT SYSDATE,
   WORKFLOW_ID                   VARCHAR2(60 Byte),
   WORKFLOW_INSTANCE_ID          VARCHAR2(100 Byte)
)
TABLESPACE APPS_TBS;

CREATE INDEX ETL_AUDIT.INDEX_RECORD_INSERT_TMSTMP
   ON ETL_AUDIT.ETL_ERR_AUDIT (TRUNC("RECORD_INSERT_TMSTMP") ASC)
   TABLESPACE APPS_TBS;


-- GRANT SELECT ON ETL_AUDIT.ETL_ERR_AUDIT TO ETL_AUDIT_RO;

--------------------------------End ETL_ERR_AUDIT--------------------------------------

--------------------------------Start PROCESS_AUDIT------------------------------------

CREATE TABLE ETL_AUDIT.PROCESS_AUDIT
(
   PROCESS_RUN_ID             NUMBER(12)                    GENERATED ALWAYS AS IDENTITY NOT NULL,
   PROCESS_TYPE_NM            VARCHAR2(50 Byte),
   INFA_SESSION_NM            VARCHAR2(100 Byte),
   INFA_MAPPING_NM            VARCHAR2(100 Byte),
   INFA_WORKFLOW_NM           VARCHAR2(100 Byte),
   INFA_WORKFLOW_RUN_ID       NUMBER(12),
   INFA_SESSION_START_TMSTMP  TIMESTAMP(6) WITH TIME ZONE,
   INFA_SESSION_END_TMSTMP    TIMESTAMP(6) WITH TIME ZONE,
   INFA_SESSION_STS_TXT       VARCHAR2(50 Byte),
   SRC_FILE_NM                VARCHAR2(100 Byte),
   TARGET_FILE_NM             VARCHAR2(100 Byte),
   SUCESS_SRC_ROW_CNT         NUMBER(12),
   FAILED_SRC_ROW_CNT         NUMBER(12),
   SUCESS_TARGET_ROW_CNT      NUMBER(12),
   FAILED_TARGET_ROW_CNT      NUMBER(12),
   PROCESS_START_TMSTMP       TIMESTAMP(6) WITH TIME ZONE,
   PROCESS_END_TMSTMP         TIMESTAMP(6) WITH TIME ZONE,
   PROCESS_STS_TXT            VARCHAR2(50 Byte),
   FIRST_ERR_CD               VARCHAR2(10 Byte),
   FIRST_ERR_MSG_TXT          VARCHAR2(255 Byte),
   LAST_ERR_CD                VARCHAR2(10 Byte),
   LAST_ERR_MSG_TXT           VARCHAR2(255 Byte),
   FILE_SIZE_IN_BITE_QTY      NUMBER(12),
   FILE_TRANSFER_ERR_TXT      VARCHAR2(255 Byte),
   RECORD_INSERT_TMSTMP       TIMESTAMP(6)                  DEFAULT SYSDATE,
   WORKFLOW_INSTANCE_ID       VARCHAR2(100 Byte)
)
TABLESPACE APPS_TBS;

-- GRANT SELECT ON ETL_AUDIT.PROCESS_AUDIT TO ETL_AUDIT_RO;
--------------------------------End PROCESS_AUDIT------------------------------------
