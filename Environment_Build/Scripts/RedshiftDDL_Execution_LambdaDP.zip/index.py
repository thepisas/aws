import psycopg2
import os
import boto3
import datetime

BUCKET_NAME = os.environ['BUCKET_NAME']
now = datetime.datetime.now()

def update_query(cursor, connection, query):
    _status = cursor.execute(query)
    result = connection.commit()
    return

def fetch_query(cursor, connection, query):
    _status = cursor.execute(query)
    result = cursor.fetchAll()
    return result
    
def get_keys():
  keys = os.environ['KEYS']
  return keys.split(",")
  
def query(event, context):
    keys = get_keys()
    _config = {
        "host": os.environ['REDSHIFT_ENDPOINT'],
        "password": os.environ['REDSHIFT_PASSWD'],
        "user": os.environ['REDSHIFT_USER'],
        "database": os.environ['REDSHIFT_DATABASE'],
        "port": os.environ['REDSHIFT_PORT']
    }
    # Get connection
    connection = psycopg2.connect(
        **_config
    )
    print("Connection Established")
    current_date = now.strftime("%Y-%m-%d")
    date_1 = datetime.datetime.strptime(current_date, "%Y-%m-%d")
    end_date = date_1 + datetime.timedelta(days=10)
    date = end_date.strftime("%Y-%m-%d")     
    try:
        s3 = boto3.client('s3')
        for key in keys:
            obj = s3.get_object(Bucket=BUCKET_NAME, Key=key)
            file_content = obj['Body'].read().decode('utf-8')
            replaced_content = file_content.replace('2019-04-10', date)
            _query = replaced_content
            with connection.cursor() as cursor:
                update_query(cursor, connection, _query)            
    except Exception as ERROR:
        print("Someting Went Wrong: " + ERROR)    
    connection.close()

    return ""