import es_common
import time

es_common.load_shared_libraries()

import os
from datetime import datetime,timedelta
from pytz import timezone

def handler(event, context):
    hosts = es_common.load_hosts()
    user = es_common.load_username()
    password = es_common.load_password()

    try:
        es_client = es_common.connect_to_elasticsearch(hosts, user, password)
    except Exception as exception:
        es_common.log_errors("Connection to Elasticsearch failed.", exception)
        exit(1)
    
    try:
        snap_get = es_client.snapshot.get(repository='edh-elasticsearch-snapshot-repo',
                                            snapshot='snapshot-*')
        for each_snap_get in snap_get:
            snap_list=snap_get[each_snap_get]
            latest_snap=snap_list[-1]
        snap_index_list=latest_snap['indices']
        print("Check latest snapshot {}".format(latest_snap['snapshot']))
    except Exception as exception:
        print("ERROR: ",exception)
        exit(1)
    
    del_index_days = os.environ['DEL_INDEX_DAYS']
    if len(del_index_days)>0:
        try:
            today = datetime.now()
            delta = timedelta(days=int(del_index_days))
            datecalc = today - delta
            del_date = datecalc.strftime("%Y%m%d")
            del_pattern = '*_'+del_date+'*'
            print("Find all indexes that match the pattern - {}".format(del_pattern))
            response = es_client.indices.get_settings(index=del_pattern)
            if len(response)>0:
                for item in response:
                    if item in snap_index_list:
                        print("Deleting Index {}".format(item))
                        del_resp = es_client.indices.delete(index=item)
                        print(del_resp)
                    else:
                        print("Index {} is not a part of the snapshot {}".format(item,latest_snap['snapshot']))
            else:
                print("No indices found")
        except Exception as e:
            print("ERROR: ",e)
            exit(2)
    else:
        print("Environment variable DEL_INDEX_DAYS has not been set")
        exit(3)