from __future__ import print_function

import es_common
import es_constants
import S3_Statuses

es_common.load_shared_libraries()

import boto3
import json
import os
import time

from elasticsearch import Elasticsearch, RequestsHttpConnection

aws_s3 = boto3.client('s3')
aws_lambda = boto3.client('lambda')

if 'MAX_BATCH_SIZE' in os.environ:
    MAX_BATCH_SIZE = int(os.environ['MAX_BATCH_SIZE'])
else:
    MAX_BATCH_SIZE = 1000

def find_doc_type(bucket_key, default_file_type = 'unknown', valid_file_types = None):
    """
    Finds document type based on bucket key.
    Expects valid_file types as a dict with the key of string found in file name and
    the value equal to the document type.
    bucket_key - file name to be tested.
    default_file_type - used if bucket_key doesn't match a valid file type or if valid_file_types is None
    valid_file_types - dict of file name parts and document types.
    """
    if valid_file_types is None:
        return default_file_type
    for key, value in iter(valid_file_types.items()):
        if key.lower() in bucket_key.lower():
            return value
    return default_file_type

def process_batch(response, current_batch, default_file_type = 'unknown', valid_file_types = None):
    """
    Takes s3 list objects response and returns a dict containing
    s3 object keys sorted by document type.
    response - s3 list objects response.
    current_batch - current batch to be uploaded.
    default_file_type - used if bucket keys don't match a valid file types
    valid_file_types - valid file types for bucket.  Varies per bucket.
    """
    raw_items = response['Contents']

    for raw_item in raw_items:
        if raw_item['Key'].endswith('/'):
            # It's a folder; skip it.
            continue
        doc_type = find_doc_type(raw_item['Key'], default_file_type, valid_file_types)
        if doc_type not in current_batch:
            current_batch[doc_type] = []
        if raw_item['Key'] not in current_batch[doc_type]:
            current_batch[doc_type].append(raw_item['Key'])
    return current_batch


def batch_files_in_bucket(bucket_name, default_file_type = 'unknown', valid_file_types = None):
    """
    Takes a bucket and lists all object keys in bucket.
    Sorts by doc_type and sends to bulk_upload lambda.
    bucket_name - bucket to be processed
    default_file_type - file type if no valid_file_types match bucket_keys
    valid_file_types - valid file types for bucket.
    """
    continue_batch_process = True
    continuation_token = None

    current_batch = {}
    batch_number = 1
    while continue_batch_process:
        # Get all objects currently in the raw bucket (i.e. not processed yet)
        if continuation_token is None:
            response = aws_s3.list_objects_v2(
                Bucket = bucket_name,
                MaxKeys = MAX_BATCH_SIZE
            )
        else:
            response = aws_s3.list_objects_v2(
                Bucket = bucket_name,
                ContinuationToken = continuation_token,
                MaxKeys = MAX_BATCH_SIZE
            )
        if response['KeyCount'] == 0:
            es_common.log_status("No new files found.  Returning")
            return
        current_batch = process_batch(response, current_batch, default_file_type, valid_file_types)
        continue_batch_process = response['IsTruncated'] and ('NextContinuationToken' in response)
        if continue_batch_process:
            continuation_token = response['NextContinuationToken']
        if len(current_batch) > 0:
            size_of_batch = 0
            for i in current_batch:
                size_of_batch = len(current_batch[i]) + size_of_batch
            print("Batch number {} of size {}".format(batch_number, size_of_batch))
            batch_number = batch_number + 1
            bulk_batch = {'BucketName':bucket_name,
                        'Files':current_batch}
            print(bulk_batch)
            print("Trigger Bulk Load Lambda - {}".format(os.environ['ES_BATCH_PROCESS_LAMBDA']))
            aws_lambda.invoke(
                FunctionName = os.environ['ES_BATCH_PROCESS_LAMBDA'],
                InvocationType = 'Event',
                Payload = json.dumps(bulk_batch)
            )
            #Reset the current batch
            bulk_batch = {}
            current_batch = {}

def handler(event, context):
    """
    Queries S3 for all objects currently in raw bucket.
    Sends keys to another lambda process which does the bulk uploading.
    """
    username = es_common.load_username('ESuser')
    password = es_common.load_password('ESpwd')
    #hosts = [os.environ['ESmaster'],os.environ['ESdatanode1'],os.environ['ESdatanode2'],os.environ['ESconfig']]
    hosts = es_common.load_hosts()

    try:
        esClient = es_common.connect_to_elasticsearch(hosts, username, password)
    except Exception as exception:
        es_common.log_errors("Connection to ES failed", exception)
    else:
        bucket_name = os.environ['ES_BUCKET']
        tricklepoll_bucket_name = os.environ['ES_TRICKLEPOLL_BUCKET']

        print("MAX_BATCH_SIZE - {}".format(MAX_BATCH_SIZE))

        print("STATUS: Procecssing Canonical Files")
        batch_files_in_bucket(bucket_name, 'unknown', es_constants.FILE_TYPES)
        print("STATUS: Procecssing TricklePoll Files")
        batch_files_in_bucket(tricklepoll_bucket_name, 'tricklepoll', None)

        es_common.enable_all_s3_event_triggers()
