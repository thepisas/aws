import es_common
import es_constants

es_common.load_shared_libraries()

import boto3
import os
import zipfile

aws_s3_client = boto3.client('s3')
aws_s3_resource = boto3.resource('s3')

current_date = es_common.get_current_date()

from datetime import date, timedelta

def get_previous_date(diff = 180):
    """
    Returns yesterday's date in the correct format.
    """
    yesterday = date.today() - timedelta(diff)
    return yesterday.strftime("%Y%m%d")


def handler(event, context):
    
    archive_date = get_previous_date(int(os.environ['ARCHIVE_DAYS']))
    folder_date = archive_date +'/'
    bucket_name = os.environ['S3_REFINED_BUCKET']
    
    print("Bucket Name- {}".format(bucket_name))
    print("Archiving files for date - {}".format(archive_date))
    
    continue_get_object = True
    continuation_token = None

    contents = []

    while continue_get_object:
        if continuation_token is None:
            response = aws_s3_client.list_objects_v2(
                Bucket = bucket_name,
                Prefix = folder_date
            )
        else:
            response = aws_s3_client.list_objects_v2(
                Bucket = bucket_name,
                ContinuationToken = continuation_token,
                Prefix = prefix
            )
        continue_get_object = response['IsTruncated'] and ('ContinuationToken' in response)
        if continue_get_object:
            continuation_token = response['ContinuationToken']
        if response['KeyCount'] == 0:
            es_common.log_status("No files to zip.  Returning.")
            return
        contents.extend(response['Contents'])

    try:
        for content in contents:
            print(content)
            response = aws_s3_client.get_object(
                Bucket = bucket_name,
                Key = content['Key']
            )
            filename = '/tmp/' + content['Key']
            
            if not os.path.exists(os.path.dirname(filename)):
                try:
                    os.makedirs(os.path.dirname(filename))
                except OSError as exc:
                    if exc.errno != errno.EEXIST:
                        raise
            aws_s3_resource.Object(bucket_name, content['Key']).download_file('/tmp/' + content['Key'])
            print("Successful Download")
        # Zipping Files
        print("Zipping files")
        zip_handle = zipfile.ZipFile('/tmp/' + archive_date + '.zip', 'w', zipfile.ZIP_DEFLATED)
        for root, dirs, files in os.walk('/tmp/'):
            for f in files:
                zip_handle.write(os.path.join(root, f))
        zip_handle.close()
        #Upload zip file to S3
        response = aws_s3_client.put_object(
            Body = open('/tmp/' + archive_date + '.zip', 'rb'),
            Bucket = bucket_name,
            Key = archive_date + '.zip',
            ServerSideEncryption = 'AES256',
            StorageClass = 'STANDARD_IA'
        )
    except Exception as E:
        print("Archival Failed")
        raise(E)
    else:    
        for content in contents:
            print("MESSAGE: Removing file")
            print(content)
            response = aws_s3_client.delete_object(
                Bucket = bucket_name,
                Key = content['Key']
            )
