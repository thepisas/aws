import es_common
import es_constants

es_common.load_shared_libraries()

import os
from elasticsearch import Elasticsearch, RequestsHttpConnection

def handler(event, context):
    print(event)

    username = es_common.load_username()
    password = es_common.load_password()
    hosts = es_common.load_hosts()

    try:
        es_client = es_common.connect_to_elasticsearch(hosts, username, password)
    except Exception as exception:
        es_common.log_errors("Connection to ES failed during delete from error index.", exception)
        exit(2)

    bucket_name, bucket_key = es_common.get_info_from_notification_event(event)
    print("S3 Object Key - {}".format(bucket_key))

    # Key will have /currentDate added to it, so we need to remove these.
    bucket_key_parts = bucket_key.split('/')
    original_date = bucket_key_parts.pop(0)
    new_bucket_key = '/'.join(bucket_key_parts)
    
    if '/canonical/' in bucket_key:
        s3_index_name_date = es_constants.S3_INDEX_PREFIX + os.environ['S3_CANONICAL_BUCKET'] + "_" + original_date
    elif '/raw/' in bucket_key:
        s3_index_name_date = es_constants.S3_INDEX_PREFIX + os.environ['S3_TRICKLEPOLL_BUCKET'] + "_" + original_date
    else:
        print("File does not follow naming standard naming convention")
        exit
    try:
        es_client.delete(
            id = new_bucket_key,
            index = s3_index_name_date,
            doc_type = 'metadata'
        )
        es_common.log_status("Successfully deleted from error index")
    except Exception as exception:
        es_common.log_errors("MESSAGE: ", exception)

