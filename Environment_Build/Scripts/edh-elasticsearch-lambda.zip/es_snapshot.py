import es_common
import time

es_common.load_shared_libraries()

import os
from datetime import datetime
from pytz import timezone
tz = timezone('EST')

current_date = datetime.now(tz).strftime("%Y%m%d-%H%M%S%f")[:-3]

def handler(event, context):
    hosts = es_common.load_hosts()
    user = es_common.load_username()
    password = es_common.load_password()

    try:
        es_client = es_common.connect_to_elasticsearch(hosts, user, password)
    except Exception as exception:
        es_common.log_errors("Connection to Elasticsearch failed.", exception)
        exit(1)

    s3_repo_name = 'edh-elasticsearch-snapshot-repo'
    snapshot_name = 'snapshot-' + current_date

    try:
        print("Creating Repository")
        es_client.snapshot.create_repository(
            repository = s3_repo_name,
            body = {
                "type": "s3",
                "settings": {
                    "bucket": os.environ['ES_SNAPSHOT_BUCKET'],
                    "region": os.environ['ES_SNAPSHOT_REGION'],
                    "base_path": s3_repo_name,
                    "server_side_encryption": True
                }
            },
            verify = True,
            timeout = '120s',
            master_timeout = '120s'
        )

        print("Creating snapshot - {}".format(snapshot_name))
        es_client.snapshot.create(
            repository = s3_repo_name,
            snapshot = snapshot_name,
            wait_for_completion = False,
            master_timeout = '120s'
        )
    except Exception as exception:
        print("Message: {}".format(exception))
