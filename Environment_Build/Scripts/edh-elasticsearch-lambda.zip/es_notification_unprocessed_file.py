from __future__ import print_function

import es_common
import es_constants
import S3_Statuses

es_common.load_shared_libraries()

import boto3
import json
import os
import time
from pytz import timezone
from datetime import date, timedelta, datetime
from elasticsearch import Elasticsearch, RequestsHttpConnection

aws_s3 = boto3.client('s3')
aws_sns = boto3.client('sns')

def check_bucket(bucket_name,search_prefix):
    """
    Takes bucket name and search prefix and checkes to see if a file 
    has been sitting in the bucket for more than X hours. If a file
    is found an email notification using SNS.
    """
    continue_batch_process = True
    continuation_token = None
    list_of_objects = None
    message_content = []
    tz = timezone('EST')
    current_date = datetime.now(tz)

    print("STATUS: Current time is {}".format(current_date))
    comparetime = current_date - timedelta(hours=int(os.environ['HOURS']))
    print("STATUS: Searching for files older than {}".format(comparetime))
    
    while continue_batch_process:
        if continuation_token is None:
            response = aws_s3.list_objects_v2(
                Bucket = bucket_name,
                Prefix = search_prefix
            )
        else:
            response = aws_s3.list_objects_v2(
                Bucket = bucket_name,
                Prefix = search_prefix,
                ContinuationToken = continuation_token
            )
        if response['KeyCount'] == 0:
            es_common.log_status("No files found.")
            return
        continue_batch_process = response['IsTruncated'] and ('NextContinuationToken' in response)
        if continue_batch_process:
            continuation_token = response['NextContinuationToken']
        list_of_objects = response['Contents']
        for objectkey in list_of_objects:
            if objectkey['Key'].endswith('/'):
                # It's a folder; skip it.
                continue

    for eachitem in list_of_objects:
        if (eachitem['LastModified']<comparetime):
            content = " MESSAGE: File {} loaded to S3 at {} is still available in the bucket - {}".format(eachitem['Key'],eachitem['LastModified'],bucket_name)
            message_content.append(content)

    if len(message_content)>0:
        email_message = '\n'.join(message_content)
        print("SENDING EMAIL: Files found")
        print(email_message)
        sns_response = aws_sns.publish(
                                        TopicArn=os.environ['SNS_TOPIC_ARN'],
                                        Subject='TCO:RFC - Unprocessed files in S3 Raw Bucket',
                                        Message=email_message
                                        )

    
def handler(event, context):
    """
    Searches for files in S3 raw bucket and checks to see if the
    files have been sitting in the raw bucket for more than X 
    number of hours
    """
    search_prefix = 'POS/'
    #Canonical Files
    messaging_bucket_name = os.environ['ES_BUCKET']
    print("STATUS: Searching for Canonical Files in bucket {}".format(messaging_bucket_name))
    check_bucket(messaging_bucket_name, search_prefix)
    
    #TricklePoll
    tricklepoll_bucket_name = os.environ['ES_TRICKLEPOLL_BUCKET']
    print("STATUS: Searching for Tricklepoll Files in bucket {}".format(tricklepoll_bucket_name))
    check_bucket(tricklepoll_bucket_name, search_prefix)

