import os
import sys

import boto3
import base64
import json
import re
import time
import urllib
from base64 import b64decode
from datetime import date, datetime

############################
### COMMON LIBRARY STUFF ###
############################

def load_shared_libraries():
    """
    Adds the libs folder to the system path.
    To keep the source folder tidy, dependencies are stored in the libs folder.
    """
    here = os.path.dirname(os.path.realpath(__file__))
    packages = os.path.join(here, "libs")
    sys.path.append(packages)

load_shared_libraries()

from elasticsearch import Elasticsearch, RequestsHttpConnection

kms = boto3.client('kms')
aws_cloudwatch = boto3.client('cloudwatch')

######################################
### ELASTICSEARCH COMMON FUNCTIONS ###
######################################

def get_current_date():
    """
    Returns the current date in the format we want for the index.
    """
    return time.strftime("%Y%m%d")

def load_hosts(host_env_variable = 'ES_HOSTS'):
    """
    Takes the name of the environment variable containing a list of
    host addresses separated by a comma.
    Returns list as array.
    """
    return os.environ[host_env_variable].split(',')

def load_username(user_env_variable = 'ES_USER'):
    """
    Takes environment variable name containing non-encrypted elastic login username.
    Returns username.
    """
    return os.environ[user_env_variable]

def load_password(password_env_variable = 'ES_PASSWORD'):
    """
    Takes environment variable name containing encrypted elastic password.
    Returns decrypted password.
    """
    ENCRYPTED = os.environ[password_env_variable]
    DECRYPTED = boto3.client('kms').decrypt(CiphertextBlob=b64decode(ENCRYPTED))['Plaintext']
    return str(DECRYPTED.decode("utf-8"))

def connect_to_elasticsearch(hosts, username, password):
    """
    Connects to Elasticsearch using the provided credentials.
    If connection is successful, returns client.
    Otherwise, logs down status to Cloudwatch and disables s3 event trigger.
    """
    print ('Connecting to the Elasticsearch endpoint')
    try:
        esClient = Elasticsearch(hosts,
                                 http_auth=(username, password),
                                 port=9200,
                                 timeout=30,
                                 use_ssl=False
        )
    except Exception as E:
        print("Error creating client - {}".format(E))
    else:
        try:
            # Check Elasticsearch cluster health
            clusterhealth=esClient.cluster.health(wait_for_status='yellow', request_timeout=30)
            print("Cluster Health - ")
            print(clusterhealth)
            print("SUCCESS: Connection to Elasticsearch established")
            print("***************")
            return esClient
        except Exception as exception:
            log_errors("Unable to connect to Elasticsearch endpoint {0}".format(esClient),
                       exception)
            metric('ClusterStatus.up', 0)
            disable_all_s3_event_triggers()
            raise(exception)

def has_file_been_loaded(esClient, bucket, key, s3indexnamesearch):
    """
    Checks if file has been previously loaded.
    """
    try:
        print("Checking if file has been processed - {}/{}".format(bucket, key))
        # Query DSL
        indexquery = {
            "query": {
                "bool": {
                    "must": [
                        { "match_phrase": { "S3BucketName": bucket }},
                        { "match_phrase": { "S3ObjectKey": key }},
                        { "match_phrase": { "ESProcessStatus": "Loaded" }}
                    ]
                }
            }
        }
        #print(indexquery)

        # Search s3-metadata-store index based on bucket and key
        retval = esClient.search(index=s3indexnamesearch, doc_type='metadata', body=indexquery)
        hits = retval['hits']['total']
        search_hit = json.dumps(retval['hits']['hits'])
        print("Number of search hits = {}".format(hits))
        print(search_hit)
        print("***************")
        if hits >= 1:
            # File has already been processed
            return True
        else:
            # New file
            return False
    except Exception as E:
        log_errors("Search on {}".format(s3indexnamesearch), E)
        return False

###########################
### S3 COMMON FUNCTIONS ###
###########################

def get_info_from_notification_event(event):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    return bucket, key

def convert_s3_to_metadata(response,
                           bucket_name,
                           bucket_key,
                           index,
                           process_status,
                           process_detail,
                           message_content):
    metadata_body = {
        'S3LastModfDate': response['LastModified'],
        'S3BucketName': bucket_name,
        'S3ObjectKey': bucket_key,
        'S3ContentSize': response['ContentLength'],
        'ESProcessDate': datetime.now(),
        'FileIndexedTo' : index,
        'ESProcessStatus': process_status,
        'ESProcessDetail': process_detail,
        'MessageContent' : message_content
    }

    return metadata_body

def convert_s3_response(response, bucket_name, bucket_key, doc_type, index_name_date):
    s3_object = response['Body'].read()

    es_object = {
        '_id': bucket_name + '/' + bucket_item,
        '_type': doc_type,
        'S3BucketName': bucket_name,
        'S3ObjectKey': bucket_item,
        'FileIndexedTo': index_name_date,
        '_source': s3_object,
        'metadata': {
            'S3LastModfDate': response['LastModified'],
            'S3BuckethName': bucket_name,
            'S3ObjectKey': bucket_key,
            'S3ContentSize': response['ContentLength'],
            'ESProcessDate': response['LastModified']
        }
    }

def get_country_code_from_file_name(file_name):
    """
    Looks for the part of the file name equal to the country code.
    Returns first instance of a two letter code surrounded by forward slashes.
    Returns None otherwise.
    """
    pattern = re.compile('\/[a-zA-Z]{2}\/')
    match = re.search(pattern, file_name)
    if match:
        return match.group(0).replace('/', '')
    else:
        return None

def move_s3_file(source_bucket, source_key, dest_bucket, dest_key):
    s3 = boto3.client('s3')
    copy_source = {
        'Bucket': source_bucket,
        'Key': source_key
    }
    config = {
        'ServerSideEncryption': 'AES256'
    }

    try:
        s3.copy(copy_source, dest_bucket, dest_key, config)
        s3.delete_object(Bucket = source_bucket, Key = source_key)
        print("MESSAGE: {}/{} moved to {}/{}".format(source_bucket,source_key,dest_bucket,dest_key))
    except Exception as exception:
        log_errors("An error occurred while trying to move {} to {}{}".format(copy_source, dest_bucket, dest_key),
                   exception)
        raise(exception)

def enable_all_s3_event_triggers():
    """
    Turns on the event triggers for both canonical and tricklepoll.
    """
    enable_s3_event_trigger(os.environ['CANONICAL_LAMBDA_ARN'], os.environ['ES_BUCKET'], 'POS/', '.json')
    enable_s3_event_trigger(os.environ['TRICKLEPOLL_LAMBDA_ARN'], os.environ['ES_TRICKLEPOLL_BUCKET'], 'POS/', '.xml')

def enable_s3_event_trigger(lambda_arn, bucket_name, prefix, suffix):
    """
    Turns back on the event trigger to ingest new items placed in S3.
    The trigger would have been turned off by either the ingest lambda function
    or the health check lambda.
    """
    log_status("Enabling ingest trigger")
    s3 = boto3.resource('s3')
    enabled_configuration = {
        'LambdaFunctionConfigurations': [
            {
                'LambdaFunctionArn': lambda_arn,
                'Events': [
                    's3:ObjectCreated:*'
                ],
                'Filter': {
                    'Key': {
                        'FilterRules': [
                            {
                                'Name': 'prefix',
                                'Value': prefix
                            },
                            {
                                'Name': 'suffix',
                                'Value': suffix
                            }
                        ]
                    }
                }
            }
        ]
    }
    try:
        bucket_notification = s3.BucketNotification(bucket_name)
        response = bucket_notification.put(NotificationConfiguration=enabled_configuration)
        log_status("Ingest trigger enabled: {}".format(response))
    except Exception as exception:
        log_errors("An error occurred while enabling event trigger", exception)
        raise(exception)

def disable_all_s3_event_triggers():
    """
    Turns off event triggers for both canonical and tricklepoll.
    """
    disable_s3_event_trigger(os.environ['ES_BUCKET'])
    disable_s3_event_trigger(os.environ['ES_TRICKLEPOLL_BUCKET'])

def disable_s3_event_trigger(bucket_name):
    disabled_configuration = {}
    log_status("Disabling ingest trigger")
    s3 = boto3.resource('s3')
    try:
        bucket_notification = s3.BucketNotification(bucket_name)
        response = bucket_notification.put(NotificationConfiguration=disabled_configuration)
        log_status("Ingest trigger disabled: {}".format(response))
    except Exception as exception:
        log_errors("An error occurred while enabling event trigge", exception)
        raise(exception)

def create_error_file_with_nonsense(bucket_name):
    """
    Test method to create a bad file for testing
    the bulk upload method.
    """
    aws_s3_client = boto3.client('s3')
    testing_bad_file = "abcdef"
    try:
        response = aws_s3_client.put_object(
            Body = testing_bad_file,
            Bucket = bucket_name,
            Key = 'POS/CN/canonical/Bad_File.json',
            ServerSideEncryption = 'AES256'
        )
        print(response)
    except Exception as exception:
        log_errors("Creating bad file failed", exception)


def create_error_file_with_nonsense_in_fields(bucket_name, key_name, file_content, fields):
    """
    bucket_name - where to place file
    key_name - name of bad file
    file_content - the content of a good file (json)
    fields - array of field names to replace with nonsense (usually date fields)
    """
    aws_s3_client = boto3.client('s3')
    for field in fields:
        file_content[field] = "asdfueqodflkjxure"

    try:
        response = aws_s3_client.put_object(
            Body = json.dumps(file_content),
            Bucket = bucket_name,
            Key = key_name,
            ServerSideEncryption = 'AES256'
        )
        print(response)
    except Exception as exception:
        log_errors("Creating bad file failed", exception)

##################################
### CLOUDWATCH COMMON FUNCTION ###
##################################

def metric(name, value, ts = None, unit = 'None', env = os.environ['ENV']):
    """
    Pushes foramtted cluster stats to Cloudwatch.
    """
    ts = ts if ts else datetime.now()
    print("Put Metric: {0}={1} {2}".format(name, value, unit))
    aws_cloudwatch.put_metric_data(
        Namespace='ES/' + env.upper() + '/Stats',
        MetricData=[{
            'MetricName': name,
            'Value': value,
            'Timestamp': ts,
            'Unit': unit
        }]
    )


################################
### LOGGING COMMON FUNCTIONS ###
################################

def log_errors(custom_message, exception):
    print("FAILED: " + custom_message)
    print("ERROR: ", exception)

def log_status(custom_message):
    print("STATUS: " + custom_message)
