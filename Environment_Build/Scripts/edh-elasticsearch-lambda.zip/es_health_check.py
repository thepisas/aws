from __future__ import print_function
import os
import sys
import es_common

es_common.load_shared_libraries()

import boto3
import json
import urllib
import base64
from elasticsearch import Elasticsearch, RequestsHttpConnection
from datetime import date, datetime

cloudwatch = boto3.client('cloudwatch')
kms = boto3.client('kms')
aws_lambda = boto3.client('lambda')

def handler(event, context):
    hosts = es_common.load_hosts()
    user = es_common.load_username()
    passwd = es_common.load_password()

    try:
        es = es_common.connect_to_elasticsearch(hosts, user, passwd)
    except Exception as exception:
        es_common.log_errors("Cluster cannot be reached or is not up.", exception)
        exit(2)

    stats = es.cluster.stats()

    nodes = stats['nodes']
    node_count = nodes['count']
    fs = nodes['fs']
    jvm = nodes['jvm']
    status = {
        'green': 0,
        'yellow': 0,
        'red': 0
    }

    es_common.metric('ClusterStatus.up', 1)
    status[stats['status']] = 1
    ts = datetime.fromtimestamp(stats['timestamp']/1000.0)
    es_common.metric('ClusterStatus.green', status['green'], ts)
    es_common.metric('ClusterStatus.yellow', status['yellow'], ts)
    es_common.metric('ClusterStatus.red', status['red'], ts)
    if status['red'] == 1:
        es_common.disable_all_s3_event_triggers()
    es_common.metric('Nodes', node_count['total'], ts)
    es_common.metric('DataNodes', node_count['data'], ts)
    es_common.metric('MasterNodes', node_count['master'], ts)
    es_common.metric('FreeStorageSpace', fs['free_in_bytes'], ts, 'Bytes')
    es_common.metric('ClusterUsedSpace', fs['total_in_bytes'], ts, 'Bytes')
    es_common.metric('CPUUtilization', nodes['process']['cpu']['percent'], ts)
    es_common.metric('JVMMemoryPressure', jvm['mem']['heap_used_in_bytes']/jvm['mem']['heap_max_in_bytes'], ts, 'Bytes')

