from __future__ import print_function

import es_common

es_common.load_shared_libraries()

import boto3
import os

s3 = boto3.resource('s3')

enabled_configuration = {
    'LambdaFunctionConfigurations': [
        {
            'LambdaFunctionArn': os.environ['ES_LAMBDA_ARN'],
            'Events': [
                's3:ObjectCreated:*'
            ],
            'Filter': {
                'Key': {
                    'FilterRules': [
                        {
                            'Name': 'prefix',
                            'Value': 'raw/'
                        },
                        {
                            'Name': 'suffix',
                            'Value': '.json'
                        }
                    ]
                }
            }
        }
    ]
}
disabled_configuration = {}

def handler(event, context):
    new_configuration = enabled_configuration
    if 'Records' in event and 'EventSource' in event['Records'][0]:
        if event['Records'][0]['EventSource'] == 'aws:sns':
            new_configuration = disabled_configuration

    bucket_name = os.environ['ES_BUCKET']
    bucket_notification = s3.BucketNotification(bucket_name)
    resp = bucket_notification.put(NotificationConfiguration=new_configuration)
