**Using Common Functions**

Any code that may be shared between multiple Lambda functions is included in the es_common file, including the loading of shared libraries.

**Installing Dependencies**

* Specify libraries to download in requirements.txt
* Run `make` in the source folder.

**Packaging Code for AWS**

* Install libraries.
* Zip together all files in the `source` folder.
* Upload zip file to Lambda function.
* Set the handler to the specific handler function needed.

**Setting Up Alarms and Triggers**

* Snapshot
  * Create Cloudwatch Events trigger to take snapshot every day.
  * Copy Daily\_Snapshot event.
  * Create new Cloudwatch Events trigger with a cron expression similar to `cron(0 3 * * ? *)`

**Lambda Descriptions**

The following descriptions can be used for the Descriptions in AWS Lambda

* es\_messaging\_ingest - Ingest data from amzs3edhmessagingrawdev into elasticsearch
* es\_health\_check - Publishes ES health check details as CloudWatch metrics
* es\_batch\_s3\_keys - Creates batches of S3 Object Keys to be sent for bulk upload to Elasticsearch.
* es\_batch\_process - Bulk uploads S3 files to Elasticsearch.
* es\_snapshot - Takes snapshot of Elastisearch Indices and stores in S3.

**Setting Lambda Environment Variables**

While each function is set to operate asynchronously, there are dependencies between functions as one lambda function often triggers another.  Any variables with the same name can be assumed to be the same between functions.

* Health Check
  * ENV - environment (DEV/QA/PROD)
  * ES\_HOSTS - IPs of clusters.  Comma separated list.
  * ES\_USER - Elasticsearch username
  * ES\_PASSWORD - Elasticsearch password (encoded)
* Messaging Ingest
  * S3error - name of S3 error bucket; where failed items will go.
  * S3refined - name of S3 refined bucket; where succesfully indexed items will go.
  * ESpwd - Elasticsearch password (encoded)
  * ESmaster - IP for master node in ES cluster.
  * ESuser - Elasticsearch username.
  * ESconfig - IP for config node in ES cluster.
  * ESdatanode1 - IP for one of the data nodes in ES cluster.
  * ESdatanode2 - IP for other data node in ES cluster.
  * INGESTION_TYPE - type of messaging processing (tricklepoll or canonical).
  * ENV
* Batch Process (Bulk Uploading into Elasticsearch)
  * ES\_HOSTS
  * ES\_USER
  * ES\_PASSWORD
  * ES\_BUCKET
  * S3\_REFINED\_BUCKET
  * S3\_ERROR\_BUCKET
  * ES\_TRICKLEPOLL\_BUCKET
  * ENV
  * ES\_USER
* Batch Process (Batching S3 Keys)
  * ENV
  * ES\_BUCKET - bucket where raw canonical messages are stored.
  * ES\_TRICKLEPOLL\_BUCKET - bucket where raw tricklepoll messages are stored.
  * ES\_BATCH\_PROCESS\_LAMBDA - Lambda name for function that does the bulk uploading.
  * TRICKLEPOLL\_LAMBDA\_ARN - Lambda ARN for tricklepoll messaging ingest.
  * CANONICAL\_LAMBDA\_ARN - Lambda ARN for canonical messaging ingest.
* Snapshot
  * ES\_HOSTS
  * ES\_USER
  * ES\_PASSWORD
  * ES\_SNAPSHOT\_BUCKET - S3 Bucket where the index snapshots will be stored.
  * ES\_SNAPSHOT\_REGION - Region for the S3 Snapshot Bucket.
* Archival
  * S3\_REFINED\_BUCKET
  * ENV

**Test Cases**

All test examples are stores in the test\_cases folder.  Below is an explanation of what the Lambda function is looking for and an example test case.

* es\_health\_check
  * Input json does not matter.
  * To test a sucess, manually confirm ES is running and the Lambda function can connect.
  * To test a failure, remove connection or take down ES cluster.
* es\_batch\_s3\_keys
  * Input json does not matter.
  * To test a success, the Lambda function must be able to hit the S3 bucket and the S3 bucket must have valid test files.
