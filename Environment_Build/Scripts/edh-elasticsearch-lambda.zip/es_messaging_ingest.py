from __future__ import print_function

import es_common

es_common.load_shared_libraries()

from es_constants import FILE_TYPES, INGESTION_TYPES

from pprint import pprint
import boto3
import urllib
import json
import os
from elasticsearch import Elasticsearch, RequestsHttpConnection
import http.client
import time
from base64 import b64decode

http.client._MAXHEADERS = 2000

s3 = boto3.client('s3')
kms = boto3.client('kms')

currentDate = es_common.get_current_date()

es_common.log_status("Loading Message Ingest function.")

s3indexname = "file_metadata_"

if os.environ['INGESTION_TYPE'].lower() == 'canonical':
    esindexname = "tlog_"
elif os.environ['INGESTION_TYPE'].lower() == 'tricklepoll':
    esindexname = "raw"
else:
    print("Please define environment variable INGESTION_TYPE correctly")
    exit(1)


def indexs3metadata(esClient,bucket,key,response,s3indexnamedate,indexnamedate,ESProcessStatus,ESProcessDetail,MessageContent):
    try:
    	print("Indexing S3 metadata")
    	retval = esClient.index(index=s3indexnamedate,
                                id = key,
                                doc_type = 'metadata',
                                body = es_common.convert_s3_to_metadata(response,
                                                                      bucket,
                                                                      key,
                                                                      indexnamedate,
                                                                      ESProcessStatus,
                                                                      ESProcessDetail,
                                                                      MessageContent
                                )
    	)
    	print("SUCCESS: S3 metadata inserted into index {}".format(s3indexnamedate))
    	print("***************")
    except Exception as E:
        es_common.log_errors("S3 metadata not indexed", E)


def indexDocElement(esClient,response,indexdoctype,s3indexnamedate,indexnamedate,bucket,key):
    try:
    	# Read S3 file body
    	resp_body = response['Body'].read()
    	print ("Loading document into ElasticSearch")
    	# Index document
    	retval = esClient.index(
            id = key,
            index = indexnamedate,
            doc_type = indexdoctype,
            body = resp_body
        )
    	print("Response from Elasticsearch: ")
    	print(retval)
    	print("Moving file to Refined Bucket")
    	indexs3metadata(esClient,bucket,key,response,s3indexnamedate,indexnamedate,'Loaded','-','-')
    	es_common.move_s3_file(bucket,
                               key,
                               os.environ['S3refined'],
                               currentDate + '/' + key)
    	print("SUCCESS: Document loaded into ElasticSearch successfully")
    	print("***************")
    except Exception as Excep:
    	print("FAILED: Document not indexed")
    	print("ERROR: ",Excep)
    	MessageContent = resp_body.decode('utf8').replace("'",'"')
    	indexs3metadata(esClient,bucket,key,response,s3indexnamedate,indexnamedate,'Failed',str(Excep),MessageContent)
    	print("Moving file to Error Bucket")
    	es_common.move_s3_file(bucket,
                               key,
                               os.environ['S3error'],
                               currentDate + '/' + key)


def handler(event, context):
    # Connect to the ElasticSearch Cluster
    # List of IP addresses are stored as Environment Variables
    username = es_common.load_username('ESuser')
    password = es_common.load_password('ESpwd')
    #hosts = [os.environ['ESmaster'],os.environ['ESdatanode1'],os.environ['ESdatanode2'],os.environ['ESconfig']]
    hosts = es_common.load_hosts()

    try:
        esClient = es_common.connect_to_elasticsearch(hosts, username, password)
    except Exception as exception:
        es_common.log_errors("Connection to ES failed during message ingest.", exception)
        exit(2)

    # Get Bucket and Key information from event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    print("Bucketname - "+bucket)
    print("Key - "+key)
    print("***************")
    # Check if this file has been processed previously
    if es_common.has_file_been_loaded(esClient, bucket, key,s3indexname+"*"):
        es_common.log_status("File has already been processed. Check index {}* for more information".format(s3indexname))
        es_common.move_s3_file(bucket,
                               key,
                               os.environ['S3refined'],
                               currentDate + '/' + key)
        return

    print("Processing file {}/{}".format(bucket,key))
    # Get S3 Object into response variable
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
    except Exception as e:
        es_common.log_errors('Failed to get object {} from bucket {}. Make sure the file exists and your bucket is in the same region as this function.'.format(key, bucket), e)
        raise e
    else:
        s3indexnamedate = s3indexname + bucket + "_" + currentDate

        country_code = es_common.get_country_code_from_file_name(key)

        if country_code is None:
            print("Invalid Object Key - No country code found. Please check S3 object Key -"+key)
            exit(3)

        # Index S3 metadata
        indexs3metadata(esClient,bucket,key,response,s3indexnamedate,'-','Processing','-','-')

        # Assume we're indexing to canonical unless being told otherwise
        ingestion_type = 'canonical'
        if 'INGESTION_TYPE' in os.environ and os.environ['INGESTION_TYPE'].lower() in INGESTION_TYPES:
            ingestion_type = os.environ['INGESTION_TYPE'].lower()


        # Determine document type based on file name
        if ingestion_type == 'canonical':
            doc_type_found = False
            for file_name_part, doc_type in iter(FILE_TYPES.items()):
                if file_name_part.lower() in key.lower():
                    # File type found; Index the contents of the file.
                    indexdoctype = doc_type
                    indexnamedate = esindexname + indexdoctype.lower() + '_' + country_code.lower() + '_' + currentDate
                    indexDocElement(esClient,response,indexdoctype,s3indexnamedate,indexnamedate,bucket,key)
                    doc_type_found = True
                    break
            if not doc_type_found:
                es_common.log_status("Uknown File Type")
                indexs3metadata(esClient,bucket,key,response,s3indexnamedate,'-','Failed','Unknown File Name','Please check file name follows standard naming convention')
                es_common.move_s3_file(bucket, key, os.environ['S3error'], currentDate + '/' + key)
        elif ingestion_type == 'tricklepoll':
            print("Tricklepoll File")
            indexdoctype = 'raw'
            indexnamedate = esindexname + '_' + country_code.lower() + '_' + currentDate
            indexDocElement(esClient, response, indexdoctype, s3indexnamedate, indexnamedate, bucket, key)
        else:
            es_common.log_status("Unsupported file type. Please define Canonical/Tricklepoll ingestion type")
            exit(4)
