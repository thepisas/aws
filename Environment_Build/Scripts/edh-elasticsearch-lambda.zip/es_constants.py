FILE_TYPES = {
    '/TranHeader_': 'TranHeader',
    '/Receipt_': 'Receipt',
    '/LineItem_': 'LineItem',
    '/Tax_': 'Tax',
    '/Tender_': 'Tender',
    '/Journal_': 'Journal',
    '/Register_': 'Register',
    '/RegisterTender_': 'RegisterTender',
    '/Store_': 'Store',
    '/TB_': 'TB',
    '/TC_': 'TC',
    '/ACTender_': 'ACTender',
    '/AC_': 'AC',
    '/ATTender_': 'ATTender',
    '/AT_': 'AT',
    '/TBTender_': 'TBTender'
}

INGESTION_TYPES = [
    'canonical',
    'tricklepoll'
]

S3_INDEX_PREFIX = "file_metadata_"
ES_INDEX_PREFIX = "tlog_"
