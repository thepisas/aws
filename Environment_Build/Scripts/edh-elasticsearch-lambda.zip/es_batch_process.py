import es_common
import es_constants

es_common.load_shared_libraries()

import boto3
import json
import os
import time

from elasticsearch import Elasticsearch, RequestsHttpConnection, helpers

aws_s3 = boto3.client('s3')
current_date = es_common.get_current_date()
current_month = time.strptime(current_date, "%Y%m%d").tm_mon
current_year = time.strptime(current_date, "%Y%m%d").tm_year

# January is in the previous fiscal year
if (current_month == 1):
    current_year -= 1

def group_items_by_status(errors, items, successful_keys, failed_keys):
    error_ids = []
    for error in errors:
        error_ids.append(error['index']['_id'])

    successful_items = []
    failed_items = []
    unindexed_items = []

    for item in items:
        es_index = item['bucket_key']
        if es_index in error_ids or es_index in failed_keys:
            failed_items.append(item)
        elif es_index in successful_keys:
            successful_items.append(item)
        else:
            unindexed_items.append(item)

    return unindexed_items, successful_items, failed_items

def bulk_move_items(items, new_bucket):
    for item in items:
        try:
            es_common.move_s3_file(item['bucket_name'],
                                   item['bucket_key'],
                                   new_bucket,
                                   current_date + '/' + item['bucket_key']
            )
        except Exception as exception:
            es_common.log_errors("Error moving file", exception)

def bulk_index_items(es_client, items):
    """
    Bulk uploads to ES all s3 objects sent to function.
    If successful, updates metadata index with loaded and moves files to Refined bucket.
    If not, updates metadata index with Failed and moves files to Error bucket.
    """
    successful_keys = []
    failed_keys = []

    unindexed_items = []
    successful_items = []
    failed_items = []
    failed_messages = {}

    try:
        actions = [
            {
                "_index": item['s3_object']['index'],
                "_id": item['bucket_key'],
                "_type": item['doc_type'],
                "_source": item['s3_object']['data'].decode("utf-8")
            } for item in items
        ]

        es_common.log_status("Starting bulk upload to Elasticsearch.")

        for success, result in helpers.streaming_bulk(es_client, actions):
            if success:
                successful_keys.append(result['index']['_id'])
            else:
                failed_keys.append(result['index']['_id'])
                failed_messages[result['index']['_id']] = result['index']['error']

        unindexed_items, successful_items, failed_items = group_items_by_status([], items, successful_keys, failed_keys)

        if len(successful_items) > 0:
            bulk_update_metadata_status(es_client, successful_items, 'Loaded', '-', '-')
            bulk_move_items(successful_items, os.environ['S3_REFINED_BUCKET'])

        if len(failed_items) > 0:
            #bulk_update_metadata_status(es_client, failed_items, 'Failed', '-', '-')
            bulk_update_metadata_status_of_failed(es_client, failed_items, failed_messages)
            bulk_move_items(failed_items, os.environ['S3_ERROR_BUCKET'])

        if len(unindexed_items) > 0:
            bulk_index_items(es_client, unindexed_items)
        else:
            es_common.log_status("Bulk copy to refined bucket complete.")

    except helpers.BulkIndexError as bulk_index_exception:
        es_common.log_errors("An BulkIndexError occurred during the bulk upload", bulk_index_exception)
        unindexed_items, successful_items, failed_items = group_items_by_status(
            bulk_index_exception.errors,
            items,
            successful_keys,
            failed_keys
        )
        for error in bulk_index_exception.errors:
            failed_messages[error['index']['_id']] = json.dumps(error)

        if len(successful_items) > 0:
            bulk_update_metadata_status(es_client, successful_items, 'Loaded', '-', '-')
            bulk_move_items(successful_items, os.environ['S3_REFINED_BUCKET'])

        if len(failed_items) > 0:
            bulk_update_metadata_status_of_failed(es_client, failed_items, failed_messages)
            bulk_move_items(failed_items, os.environ['S3_ERROR_BUCKET'])

        if len(unindexed_items) > 0:
            bulk_index_items(es_client, unindexed_items)

    except Exception as exception:
        es_common.log_errors("An error occurred during bulk upload.", exception)
        bulk_update_metadata_status(es_client, items, 'Failed', str(exception), '-')
        es_common.log_status("Moving all items to Error bucket.")
        bulk_move_items(items, os.environ['S3_ERROR_BUCKET'])


def bulk_update_metadata_status(es_client, full_objects, process_status, process_detail, message_content):
    for i in range(0, len(full_objects)):
        full_objects[i]['metadata_object']['data']['ESProcessStatus'] = process_status
        full_objects[i]['metadata_object']['data']['ESProcessDetail'] = process_detail
        full_objects[i]['metadata_object']['data']['MessageContent'] = message_content
    bulk_index_metadata(es_client, full_objects)

def bulk_update_metadata_status_of_failed(es_client, failed_objects, failed_reasons):
    print(failed_reasons)
    for i in range(0, len(failed_objects)):
        process_status = 'Failed'
        process_detail = '-'
        message_content = '-'
        try:
            process_detail = "Bulk Load error"
            message_content = failed_reasons[failed_objects[i]['bucket_key']]
        except Exception as exception:
            es_common.log_errors("Error getting specific error", exception)
            process_detail = "Bulk load error; error getting error content from bulk load error"
        failed_objects[i]['metadata_object']['data']['ESProcessStatus'] = process_status
        failed_objects[i]['metadata_object']['data']['ESProcessDetail'] = process_detail
        failed_objects[i]['metadata_object']['data']['MessageContent'] = message_content
    print(failed_objects)
    bulk_index_metadata(es_client, failed_objects)

def bulk_index_metadata(es_client, items):
    """
    Bulk index s3 metadata for indexed s3 objects.
    """
    es_common.log_status("Bulk indexing S3 metadata")
    try:
        actions = [
            {
                "_index": item['metadata_object']['index'],
                "_type": 'metadata',
                "_id": item['bucket_key'],
                "_source": item['metadata_object']['data']
            } for item in items
        ]
        response = helpers.bulk(es_client, actions)
        print(response)
    except Exception as exception:
        es_common.log_errors("S3 metadata not indexed during bulk process.", exception)

def handler(event, context):
    """
    Takes in a dict containing with the key being a doc_type
    and value being a list of s3 object keys belonging to that doc_type.
    Bulk loads into ES all keys sent in batch.
    """
    hosts = es_common.load_hosts()
    username = es_common.load_username()
    password = es_common.load_password()

    # Connect to ElasticSearch
    try:
        es_client = es_common.connect_to_elasticsearch(hosts, username, password)
    except Exception as exception:
        es_common.log_errors("Connection to ES Failed during bulk load process; returning.", exception)
        exit(2)

    messaging_ingest_bucket_name = os.environ['ES_BUCKET']
    tricklepoll_bucket_name = os.environ['ES_TRICKLEPOLL_BUCKET']

    s3_index_name = es_constants.S3_INDEX_PREFIX
    es_index_name = es_constants.ES_INDEX_PREFIX

    print(s3_index_name)
    print(es_index_name)
    print(event)
    
    bucket_name = event['BucketName']
    event_files = event['Files']

    full_objects = []
    unknown_objects = []

    for doc_type in event_files:
        #bucket_name = tricklepoll_bucket_name if doc_type == 'tricklepoll' else  messaging_ingest_bucket_name

        for bucket_item in event_files[doc_type]:
            country_code = es_common.get_country_code_from_file_name(bucket_item)

            if country_code is None:
                country_code = 'CN'

            if es_common.has_file_been_loaded(es_client, bucket_name, bucket_item, "file_metadata_*"):
                es_common.log_status("File has already been processed. Check index {}* for more information".format(s3_index_name))
                es_common.move_s3_file(bucket_name,
                                        bucket_item,
                                        os.environ['S3refined'],
                                        current_date + '/' + bucket_item)                
                continue

            try:
                response = aws_s3.get_object(
                    Bucket = bucket_name,
                    Key = bucket_item
                )
            except Exception as exception:
                es_common.log_errors(
                    "Failed to get object {} from bucket {}. Make sure the file exists and your bucket is in the same region as this function.".format(bucket_name, bucket_item),
                    exception)
                continue

            s3_object = response['Body'].read()

            s3_object_index = es_index_name + doc_type.lower() + '_' + str(current_year)
            
            if doc_type.lower() == 'tricklepoll':
                s3_object_index = 'raw_' + str(current_year)

            converted_object = {
                'bucket_name': bucket_name,
                'bucket_key': bucket_item,
                'doc_type': 'raw' if doc_type == 'tricklepoll' else doc_type,
                's3_object': {
                    'index': s3_object_index,
                    'data': s3_object
                },
                'metadata_object': {
                    'index': s3_index_name + bucket_name + '_' + str(current_year),
                    'data': es_common.convert_s3_to_metadata(response,
                                                             bucket_name,
                                                             bucket_item,
                                                             s3_object_index,
                                                             'Processing', '-', '-'
                    )
                }
            }
            if doc_type == 'unknown':
                unknown_objects.append(converted_object)
            else:
                full_objects.append(converted_object)

    print("Size of bulk upload: {}".format(len(full_objects)))
    if len(full_objects) > 0:
        # Set all items to Processing status
        bulk_index_metadata(es_client, full_objects)

        # Bulk upload items
        bulk_index_items(es_client, full_objects)

    if len(unknown_objects) > 0:
        bulk_update_metadata_status(es_client, unknown_objects, 'Failed', 'Unknown File Name', 'Please check file name follows standard naming convention.')
        for unknown_object in unknown_objects:
            try:
                es_common.move_s3_file(unknown_object['bucket_name'],
                                       unknown_object['bucket_key'],
                                       os.environ['S3_ERROR_BUCKET'],
                                       current_date + '/' + unknown_object['bucket_key']
                )
            except Exception as exception:
                es_common.log_errors("Error moving file", exception)
