#!/usr/bin/env bash

#********************************IMPORTANT***************
#********************************InputParameterfile***************
AWS_PROFILE=
RDSMySQLParameterStoreName=RDS_MySQL_MasterUserPassword_Stg
RDSMySQLPassword=Temp12345
RDSOracleParameterStoreName=RDS_Oracle_MasterUserPassword_Stg
RDSOraclePassword=Temp12345
RDSRedshiftParameterStoreName=Redshift_MasterUserPassword_Stg
RDSRedshiftPassword=Temp12345
ESNonDefaultUserPS=ElasticSearch_DefaultSuperUserName_Stg
ESParmStrNonDefaultUserName=lambdauserstg
ELSStrNonDefaultUserPswd=ElasticSearch_DefaultSuperUserPassword_Stg
ESParmStrNonDefaultUserPswd=Temp12345
ELSResetDefaultUserPswd=ElasticSearch_LambdaESUserPassword_Stg
ESParmStrResetDefaultUserPswd=Temp12345
ELSLDAPBindPassword=ElasticSearch_LDAPBindPassword_Stg
ESParmStrLDAPBindPswd=Temp12345
KeypairName=EDH-TCO-STG
EMRFilesBucketName=amzs3pkgemrscriptsstg
SourceEMRBucketName=amzs3edhpkgprod



