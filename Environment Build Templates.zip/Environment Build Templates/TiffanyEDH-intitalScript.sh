#!/usr/bin/env bash
aws ssm put-parameter --name "MySQLRDSUserPassword" --type "String" --value "Temp12345"
aws ssm put-parameter --name "OracleRDSUserPassword" --type "String" --value "Temp12345"
aws ssm put-parameter --name "RedshiftUserPassword" --type "String" --value "Temp12345"
aws ssm put-parameter --name "ELSStrNonDefaultUserName" --type "String" --value "Temp12345"
aws ssm put-parameter --name "ELSStrNonDefaultUserPswd" --type "String" --value "Temp12345"
aws ssm put-parameter --name "ELSResetDefaultUserPswd" --type "String" --value "Temp12345"
aws ssm put-parameter --name "ELSLDAPBindPassword" --type "String" --value "Temp12345"
if [ $? -eq 0 ]; then
    echo "SSM Parmeter Store is created"
else
    echo "SSM Parameter FAILED to create"
fi 
aws s3api create-bucket --bucket "$1"
aws s3 cp s3://"$2"/ s3://"$1"/ --recursive
if [ $? -eq 0 ]; then
    echo "EMR Copy Bucket Successfully"
else
    echo "EMR Copy Bucket FAILED to Copy Files"
fi 
key=(aws ec2 create-key-pair --key-name "EDH-TCO-STG" --query 'KeyMaterial' --output text)
aws ssm put-parameter --name "EDHSTGKeyPair" --type "String" --value key