#!/usr/bin/env bash
source inputParameterFile.sh

echo "Generating STS token for MFA Login using temporary credentials"
aws sts get-session-token --duration $DURATION --serial-number $ARN_OF_MFA --token-code $MFA_TOKEN_CODE --profile $AWS_USER_PROFILE --output text > output
if [ $? -eq 0 ]; then
    echo "Token Generated"
else
    echo "Token FAILED to Generated"
fi 
AWS_ACCESS_KEY_ID=$(awk '{print $2}' output)
AWS_SECRET_ACCESS_KEY=$(awk '{print $4}' output)
AWS_SESSION_TOKEN=$(awk '{print $5}' output)

echo "Temporary credentials:"
echo "AWS_ACCESS_KEY_ID: " $AWS_ACCESS_KEY_ID
echo "AWS_SECRET_ACCESS_KEY: " $AWS_SECRET_ACCESS_KEY
echo "AWS_SESSION_TOKEN: " $AWS_SESSION_TOKEN

export  AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID
export  AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY
export  AWS_SESSION_TOKEN=$AWS_SESSION_TOKEN
if [ $? -eq 0 ]; then
    echo "Login Successfull"
else
    echo "Login FAIL"
fi 
echo "Creating KeyPair for SSH Login"
aws ec2 create-key-pair --key-name $KeypairName --output text > TC0-EDH-TEST.pem
if [ $? -eq 0 ]; then
    echo "KeyPair Created Successfully"
else
    echo "Keypair Creation FAILED"
fi
echo "Creating Amazon S3 bucket to Upload all the EDH Cloudformation Template"
aws s3api create-bucket --bucket $CFTBucketName
if [ $? -eq 0 ]; then
    echo "S3 Bucket was created Successfully"
else
    echo "S3 Bucket Creation FAILED"
fi 
echo "Uploading the Cloudformation Template from Local Directory to the Above created S3 Bucket"
aws s3 cp $DirectoryPath s3://$CFTBucketName/ --recursive
aws s3 cp $DirectoryPath s3://$CFTBucketName/ --recursive
aws s3 cp $DirectoryPath s3://$CFTBucketName/ --recursive
if [ $? -eq 0 ]; then
    echo "CFN templates uploaded Successfully"
else
    echo "CFN templates FAILED to upload"
fi 
