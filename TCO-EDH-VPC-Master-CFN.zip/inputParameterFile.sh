#!/usr/bin/env bash

#********************************IMPORTANT***************
#********************************InputParameterfile***************
AWS_USER_PROFILE=
ARN_OF_MFA=
MFA_TOKEN_CODE=
KeypairName=TCO-EDH-STG
CFTBucketName=amzs3cloudformationscriptstg
DirectoryPath=/tmp/
DURATION=99999

